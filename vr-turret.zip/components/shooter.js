AFRAME.registerComponent('shooter', {
    init: function() {
        this.lastShot = 0;
    },
    tick(time, timeDelta) {
        if (time - this.lastShot > 500) {
            this.lastShot = time;
            const p = new THREE.Vector3();
            this.el.object3D.getWorldPosition(p);
            const q = new THREE.Quaternion();
            this.el.object3D.getWorldQuaternion(q);

            //convert direction to velocity
            const v = new THREE.Vector3(0, 0, -0.02);
            v.applyQuaternion(q);
            
            const projectile = document.createElement('a-entity');
            projectile.setAttribute('projectile', 'velocity', v);                        
            projectile.setAttribute('position', {x: p.x, y: p.y, z: p.z});
            projectile.setAttribute('geometry', { primitive: 'circle', radius: 0.03, segments: 3 });            
            projectile.setAttribute('obb-collider', 'size', {x: 0.03, y: 0.03, z: 0.03});
            this.el.sceneEl.appendChild(projectile);
        }
    }
});