
AFRAME.registerComponent('turret', {
    data: {
        cursor: {type: 'string', default: '#cursor'}
    },
    init: function() {
        console.log("turret init");
        this.data.cursor = document.querySelector('#cursor');
    },
    tick: function(time, timeDelta) {
        const cursor = this.data.cursor;
        if (cursor) {            
            const raycaster = cursor.components.raycaster;
            const intersections = raycaster.intersections;
            if (intersections.length > 0) {
                console.log("turret tick");
                const p = intersections[0].point;
                
                // rotate towards p
                var o = new THREE.Vector3();
                this.el.object3D.getWorldPosition(o);
                o.sub(p).normalize();
                const rotation = {
                    x: -THREE.MathUtils.radToDeg(Math.asin(o.y)),
                    z: -90,
                    y: THREE.MathUtils.radToDeg(Math.atan2(o.x, o.z))
                }
                this.el.setAttribute('rotation', rotation);
            }
        }        
    }
})
